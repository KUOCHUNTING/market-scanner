from ta.momentum import RSIIndicator, ROCIndicator
from ta.volume import OnBalanceVolumeIndicator
import pandas as pd

# ✅ TMO 計算（Momentum Spread）
def calculate_tmo(df, short_period=5, long_period=20):
    price = df['close']
    short_ema = price.ewm(span=short_period).mean()
    long_ema = price.ewm(span=long_period).mean()
    return short_ema - long_ema

# ✅ 指標總整合（建議先檢查 df 是否足夠長）
def calculate_indicators(df):
    if len(df) < 25:
        print("[警告] 資料過短，無法正確計算指標")
        return None

    indicators = {}

    indicators["rsi"] = RSIIndicator(close=df['close'], window=6).rsi()
    indicators["tmo"] = calculate_tmo(df)
    indicators["vwap"] = (df['close'] * df['volume']).cumsum() / df['volume'].cumsum()
    indicators["obv"] = OnBalanceVolumeIndicator(close=df['close'], volume=df['volume']).on_balance_volume()
    indicators["ema5"] = df['close'].ewm(span=5).mean()
    indicators["ema20"] = df['close'].ewm(span=20).mean()
    indicators["roc"] = ROCIndicator(close=df['close'], window=5).roc()

    return indicators
