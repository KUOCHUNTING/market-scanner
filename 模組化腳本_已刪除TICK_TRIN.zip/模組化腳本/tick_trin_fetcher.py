import os
import requests
from datetime import datetime, timedelta
import gspread
import base64
import pandas as pd
from oauth2client.service_account import ServiceAccountCredentials

POLYGON_API_KEY = os.getenv("POLYGON_API_KEY")
SPREADSHEET_ID = os.getenv("GOOGLE_SPREADSHEET_ID")
GSERVICE_KEY = os.getenv("GOOGLE_SERVICE_ACCOUNT_BASE64")

# ✅ Sheets 認證
def get_gspread_client():
    credentials_info = base64.b64decode(GSERVICE_KEY).decode("utf-8")
    credentials_dict = eval(credentials_info)
    scope = ["https://spreadsheets.google.com/feeds", "https://www.googleapis.com/auth/drive"]
    credentials = ServiceAccountCredentials.from_json_keyfile_dict(credentials_dict, scope)
    return gspread.authorize(credentials)

def fetch_tick_and_trin():
    try:
        tick_res = requests.get(tick_url, timeout=10).json()
        trin_res = requests.get(trin_url, timeout=10).json()

        tick_value = tick_res['results'][0]['c'] if 'results' in tick_res else None
        trin_value = trin_res['results'][0]['c'] if 'results' in trin_res else None

        if tick_value is None or trin_value is None:

        return float(tick_value), float(trin_value)

    except Exception as e:
        return None, None

def write_tick_to_sheets(tick_value, trin_value):
    try:
        gc = get_gspread_client()
        sh = gc.open_by_key(SPREADSHEET_ID)

        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        worksheet.append_row([now, tick_value, trin_value])
    except Exception as e:
        print(f"[錯誤] 無法寫入 Sheets：{e}")
