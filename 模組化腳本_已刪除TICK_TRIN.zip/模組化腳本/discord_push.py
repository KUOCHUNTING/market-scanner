import requests
import os

DISCORD_WEBHOOK = os.getenv("DISCORD_WEBHOOK")

def push_to_discord(signal):
    if not DISCORD_WEBHOOK:
        print("[錯誤] 未設定 DISCORD_WEBHOOK 環境變數，無法發送推播")
        return

    symbol = signal["symbol"]
    price = signal["price"]
    rsi = signal["rsi"]
    tmo = signal["tmo"]
    roc = signal["roc"]
    vwap_diff = signal["vwap_diff"]
    note = signal["note"]
    direction = signal["direction"]

    emoji = "🐂" if direction == "多" else "🐻"

    msg = (
        f"⚠️ **[價格背離 - {direction}頭預警]** {emoji} {symbol}\n"
        f"💰 價格：${price:.2f}｜VWAP 乖離：{vwap_diff:.2%}\n"
        f"📊 RSI：{rsi:.1f}｜TMO：{tmo:.2f}｜ROC：{roc:.2f}\n"
        f"📝 備註：{note}"
    )

    try:
        response = requests.post(DISCORD_WEBHOOK, json={"content": msg})
        if response.status_code != 204:
            print(f"[錯誤] Discord 回應異常：{response.status_code} - {response.text}")
    except Exception as e:
        print(f"[例外] 發送 Discord 推播失敗：{e}")
