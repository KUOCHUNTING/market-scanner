from polygon import RESTClient
import pandas as pd
from datetime import datetime, timedelta
import pytz
import os
from dotenv import load_dotenv
load_dotenv()

POLYGON_API_KEY = os.getenv("POLYGON_API_KEY")

def fetch_stock_data(symbol):
    if not POLYGON_API_KEY:
        print("[錯誤] POLYGON_API_KEY 未設定，請確認 Render 環境變數或 .env 檔")
        return None

    try:
        client = RESTClient(api_key=POLYGON_API_KEY)
        est = pytz.timezone("US/Eastern")
        now = datetime.now(est)
        end = now - timedelta(minutes=15)
        start = end - timedelta(hours=2)

        from_str = start.strftime("%Y-%m-%dT%H:%M:%S")
        to_str = end.strftime("%Y-%m-%dT%H:%M:%S")

        aggs = client.get_aggs(
            ticker=symbol,
            multiplier=15,
            timespan="minute",
            from_=from_str,
            to=to_str,
            limit=100
        )

        if not hasattr(aggs, 'results') or not aggs.results:
            print(f"[警告] {symbol} 無有效 bars 資料，可能無成交或非主板股票")
            return None

        df = pd.DataFrame(aggs.results)
        df['timestamp'] = pd.to_datetime(df['t'], unit='ms')
        df.set_index('timestamp', inplace=True)
        df.rename(columns={'c': 'close', 'o': 'open', 'h': 'high', 'l': 'low', 'v': 'volume'}, inplace=True)
        df.sort_index(inplace=True)
        return df

    except Exception as e:
        print(f"[ERROR] 無法抓取 {symbol} 資料：{e}")
        return None
