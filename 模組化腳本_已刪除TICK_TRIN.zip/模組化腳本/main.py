from sheets_logger import log_trade_to_sheets, log_exit_to_sheets
import time
import os
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed

# ✅ Debug 啟動
print("[DEBUG] main.py 已啟動")
print("[DEBUG] 目前檔案列表：", os.listdir())

# ✅ 主要功能模組
from fetch_data import fetch_stock_data
from indicators import calculate_indicators
from signals import evaluate_entry_signal
from discord_push import push_to_discord
from sheets_logger import log_trade_to_sheets
from positions import manage_positions

from tick_trin_handler import (
    load_tick_history, calculate_tick_percentile, calculate_tick_slope,
    is_tick_extreme_bullish, is_tick_extreme_bearish,
    is_trin_bullish, is_trin_bearish
)
from tick_trin_fetcher import fetch_tick_and_trin, write_tick_to_sheets

# ✅ 讀取股票清單
def load_stock_list(filepath="filtered_us_stocks_common_only.csv"):
    try:
        df = pd.read_csv(filepath)
        return df["symbol"].dropna().unique().tolist()
    except Exception as e:
        print(f"[錯誤] 無法讀取股票清單：{e}")
        return []

# ✅ 處理單一股票邏輯（進場＋推播＋紀錄）
def process_stock(symbol, tick_info):
    try:
        print(f"[INFO] 處理中：{symbol}")
        df = fetch_stock_data(symbol)
        if df is None:
            return f"[警告] {symbol} 抓不到資料，跳過"

        indicators = calculate_indicators(df)
        if indicators is None:
            print(f"[略過] {symbol} 指標無法計算，資料太短")
            return f"[略過] {symbol} 無效資料"

        signal = evaluate_entry_signal(symbol, df, indicators)

        if signal:
            signal["tick_percentile"] = tick_info["percentile"]
            signal["tick_slope"] = tick_info["slope"]
            signal["trin"] = tick_info["trin"]
            signal["tick_confluence"] = tick_info["bull"] if signal["type"] == "long" else tick_info["bear"]

            print(f"[訊號] {symbol} 出現進場條件：{signal['type']}（共振：{signal['tick_confluence']}）")
            push_to_discord(signal)
            log_trade_to_sheets(signal)
            manage_positions(symbol, signal)
        else:
            print(f"[略過] {symbol} 無進場訊號")

        # ✅ 無論有沒有訊號，最後都檢查是否該出場
        latest_price = df['close'].iloc[-1]
        check_exit_conditions(symbol, latest_price)

        return f"[完成] {symbol} 全流程處理完畢"

    except Exception as e:
        return f"[錯誤] {symbol} 處理失敗：{e}"

# ✅ 每輪掃描（多執行緒）
def run_scanner(stock_list, tick_info, max_threads=20):
    with ThreadPoolExecutor(max_workers=max_threads) as executor:
        futures = {executor.submit(process_stock, symbol, tick_info): symbol for symbol in stock_list}
        for future in as_completed(futures):
            result = future.result()
            print(result)

# ✅ 主程式
if __name__ == "__main__":
    stock_list = load_stock_list()
    if not stock_list:
        print("[錯誤] 股票清單為空，請確認 CSV 是否存在")
        exit()

    print(f"[啟動成功] 掃描全美股，共 {len(stock_list)} 檔，每 60 秒掃描一次，使用多執行緒加速")

    while True:
        tick_value, trin_value = fetch_tick_and_trin()
        if tick_value is None or trin_value is None:
            time.sleep(60)
            continue

        # ✅ 寫入 Sheets
        write_tick_to_sheets(tick_value, trin_value)

        # ✅ 分析歷史與共振狀態
        tick_history = load_tick_history()
        percentile = calculate_tick_percentile(tick_value, tick_history)
        slope = calculate_tick_slope(tick_history)
        bull = is_tick_extreme_bullish(percentile, slope) and is_trin_bullish(trin_value)
        bear = is_tick_extreme_bearish(percentile, slope) and is_trin_bearish(trin_value)

        tick_info = {
            "percentile": percentile,
            "slope": slope,
            "trin": trin_value,
            "bull": bull,
            "bear": bear,
        }

        run_scanner(stock_list, tick_info, max_threads=20)
        print("[等待中] 下一輪掃描將於 60 秒後執行...\n")
        time.sleep(60)
