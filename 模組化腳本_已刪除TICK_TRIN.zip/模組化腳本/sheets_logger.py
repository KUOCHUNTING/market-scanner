import gspread
from datetime import datetime
from google.oauth2.service_account import Credentials
import os
import base64
import json

def log_trade_to_sheets(signal):
    try:
        # ✅ 認證與 Sheets 連接
        creds_data = json.loads(base64.b64decode(os.getenv("GOOGLE_SERVICE_ACCOUNT_BASE64")))
        creds = Credentials.from_service_account_info(creds_data, scopes=["https://www.googleapis.com/auth/spreadsheets"])
        client = gspread.authorize(creds)
        sheet = client.open_by_key(os.getenv("GOOGLE_SPREADSHEET_ID"))

        try:
            worksheet = sheet.worksheet("交易紀錄")
        except gspread.exceptions.WorksheetNotFound:
            worksheet = sheet.add_worksheet(title="交易紀錄", rows="1000", cols="20")
            worksheet.append_row(["時間", "代號", "方向", "進場價", "RSI", "TMO", "ROC", "VWAP乖離", "備註"])

        # ✅ 寫入交易資料
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        worksheet.append_row([
            now,
            signal.get("symbol", ""),
            signal.get("direction", ""),
            round(signal.get("price", 0), 2),
            round(signal.get("rsi", 0), 2),
            round(signal.get("tmo", 0), 2),
            round(signal.get("roc", 0), 2),
            round(signal.get("vwap_diff", 0), 4),
            signal.get("note", "")
        ])

        print(f"[寫入成功] 已寫入 Sheets：{signal['symbol']}")

    except Exception as e:
        print(f"[錯誤] 寫入 Google Sheets 失敗：{e}")

import gspread
from datetime import datetime
from google.oauth2.service_account import Credentials
import os
import base64
import json

def log_exit_to_sheets(symbol, entry_price, exit_price, direction, pnl_pct, profit, reason):
    try:
        # ✅ 認證與連線
        creds_data = json.loads(base64.b64decode(os.getenv("GOOGLE_SERVICE_ACCOUNT_BASE64")))
        creds = Credentials.from_service_account_info(creds_data, scopes=["https://www.googleapis.com/auth/spreadsheets"])
        client = gspread.authorize(creds)
        sheet = client.open_by_key(os.getenv("GOOGLE_SPREADSHEET_ID"))

        try:
            worksheet = sheet.worksheet("出場紀錄")
        except gspread.exceptions.WorksheetNotFound:
            worksheet = sheet.add_worksheet(title="出場紀錄", rows="1000", cols="20")
            worksheet.append_row(["時間", "代號", "方向", "進場價", "出場價", "報酬率", "損益金額", "出場理由"])

        # ✅ 寫入出場紀錄
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        worksheet.append_row([
            now,
            symbol,
            direction,
            round(entry_price, 2),
            round(exit_price, 2),
            f"{pnl_pct:.2%}",
            round(profit, 2),
            reason
        ])

        print(f"[寫入成功] 已寫入出場紀錄：{symbol}｜報酬：{pnl_pct:.2%}")

    except Exception as e:
        print(f"[錯誤] 寫入出場紀錄失敗：{e}")

