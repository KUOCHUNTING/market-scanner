import numpy as np
from datetime import datetime
import pandas as pd

# === 設定百分位區間範圍 ===

def calculate_tick_percentile(current_tick, tick_history):
    try:
        tick_values = tick_history['tick']
        percentile = np.sum(tick_values < current_tick) / len(tick_values) * 100
        return round(percentile, 2)
    except Exception as e:
        return None

def calculate_tick_slope(tick_history):
    try:
        if len(tick_history) < 3:
            return 0
        # 只取最近 3 筆計算簡單斜率
        x = np.arange(3)
        y = tick_history['tick'].iloc[-3:].values
        slope = np.polyfit(x, y, 1)[0]
        return round(slope, 2)
    except Exception as e:
        return 0

def is_tick_extreme_bullish(percentile, slope):
    return percentile >= 95 and slope > 0

def is_tick_extreme_bearish(percentile, slope):
    return percentile <= 5 and slope < 0

def is_trin_bullish(trin_value):
    return trin_value < 1

def is_trin_bearish(trin_value):
    return trin_value > 1

def load_tick_history():
    try:
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        return df
    except Exception as e:
        return pd.DataFrame()

def save_tick_value(timestamp, value):
    try:
        df = load_tick_history()
        new_row = {'timestamp': timestamp, 'tick': value}
        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        df = df.tail(200)  # 限制只保留最近 200 筆
    except Exception as e:
