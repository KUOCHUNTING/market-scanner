from datetime import datetime

positions = {}

def manage_positions(symbol, signal):
    if symbol in positions:
        return  # 已持有，不重複建倉

    price = signal["price"]
    direction = signal["direction"]
    entry_time = datetime.now().strftime("%Y-%m-%d %H:%M")
    amount = 5000  # 每筆投入資金

    # === 三段停利與停損設定 ===
    stop_loss = price * 0.98         # -2%
    take_profit_1 = price * 1.03     # +3%
    take_profit_2 = price * 1.05     # +5%
    take_profit_3 = price * 1.08     # +8%

    positions[symbol] = {
        "entry_price": price,
        "entry_time": entry_time,
        "direction": direction,
        "entry_amount": amount,
        "stop_loss": stop_loss,
        "tp1": take_profit_1,
        "tp2": take_profit_2,
        "tp3": take_profit_3,
        "trail_trigger": take_profit_1,
        "trail_margin": 0.02,  # 2% 移動保利
        "trail_active": False,
        "trail_high": price if direction == "多" else None,
        "trail_low": price if direction == "空" else None,
        "tp_status": 0  # 停利階段（0未達，1第一段...）
    }

    print(f"[持倉紀錄] {symbol} 進場 @ ${price:.2f}（{direction}）")

def check_exit_conditions(symbol, latest_price):
    if symbol not in positions:
        return  # ❌ 若尚未持倉則不做判斷

    pos = positions[symbol]
    dir = pos["direction"]

    # === 📈 多單停利條件 ===
    if dir == "多":
        if latest_price >= pos["tp3"]:
            exit_position(symbol, latest_price, "三段停利（+8%）")
        elif latest_price >= pos["tp2"] and pos["tp_status"] < 2:
            pos["tp_status"] = 2
            print(f"[鎖利2] {symbol} 第二段停利觸發 (+5%)")
        elif latest_price >= pos["tp1"] and pos["tp_status"] < 1:
            pos["tp_status"] = 1
            print(f"[鎖利1] {symbol} 第一段停利觸發 (+3%)")

    # === 📉 空單停利條件 ===
    elif dir == "空":
        if latest_price <= pos["tp3"]:
            exit_position(symbol, latest_price, "三段停利（+8%）")
        elif latest_price <= pos["tp2"] and pos["tp_status"] < 2:
            pos["tp_status"] = 2
            print(f"[鎖利2] {symbol} 第二段停利觸發 (+5%)")
        elif latest_price <= pos["tp1"] and pos["tp_status"] < 1:
            pos["tp_status"] = 1
            print(f"[鎖利1] {symbol} 第一段停利觸發 (+3%)")

    # === ⛔ 固定停損條件 ===
    if dir == "多" and latest_price <= pos["stop_loss"]:
        exit_position(symbol, latest_price, "停損出場")
    elif dir == "空" and latest_price >= pos["stop_loss"]:
        exit_position(symbol, latest_price, "停損出場")

    # === 🌀 移動停利判斷（Trailing Stop）===
    trail_stop_update(symbol, latest_price)

def trail_stop_update(symbol, latest_price):
    pos = positions[symbol]
    dir = pos["direction"]

    if not pos["trail_active"]:
        # ✅ 觸發移動停利
        if (dir == "多" and latest_price >= pos["trail_trigger"]) or \
           (dir == "空" and latest_price <= pos["trail_trigger"]):
            pos["trail_active"] = True
            print(f"[移動停利啟動] {symbol}")

    if pos["trail_active"]:
        if dir == "多":
            if latest_price > pos["trail_high"]:
                pos["trail_high"] = latest_price
            stop_price = pos["trail_high"] * (1 - pos["trail_margin"])
            if latest_price <= stop_price:
                exit_position(symbol, latest_price, f"移動停利出場（{stop_price:.2f}）")
        else:
            if latest_price < pos["trail_low"]:
                pos["trail_low"] = latest_price
            stop_price = pos["trail_low"] * (1 + pos["trail_margin"])
            if latest_price >= stop_price:
                exit_position(symbol, latest_price, f"移動停利出場（{stop_price:.2f}）")

def exit_position(symbol, exit_price, reason):
    if symbol not in positions:
        print(f"[警告] {symbol} 不在持倉中，無法出場")
        return

    pos = positions[symbol]
    entry_price = pos["entry_price"]
    direction = pos["direction"]
    pnl = (exit_price - entry_price) if direction == "多" else (entry_price - exit_price)
    pnl_pct = pnl / entry_price
    amount = pos["entry_amount"]
    profit = pnl_pct * amount

    print(f"💸 [出場] {symbol} @ ${exit_price:.2f}｜理由：{reason}")
    print(f"📊 報酬：{pnl_pct:.2%}｜損益：${profit:.2f}｜方向：{direction}")

    # ✅ 可選擇記錄出場
    # write_exit_to_sheets(symbol, exit_price, profit, reason, direction)

    del positions[symbol]
