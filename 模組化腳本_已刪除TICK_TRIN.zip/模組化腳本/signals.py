
def evaluate_entry_signal(symbol, df, indicators):
    price = df['close'].iloc[-1]
    rsi = indicators["rsi"]
    tmo = indicators["tmo"]
    roc = indicators["roc"]
    vwap = indicators["vwap"]
    obv = indicators["obv"]
    ema5 = indicators["ema5"].iloc[-1]
    ema20 = indicators["ema20"].iloc[-1]

    latest_rsi = rsi.iloc[-1]
    latest_tmo = tmo.iloc[-1]
    latest_roc = roc.iloc[-1]
    latest_vwap = vwap.iloc[-1]
    latest_obv = obv.iloc[-1]

    if (
        df['close'].iloc[-1] < df['close'].iloc[-3] and
        rsi.iloc[-1] > rsi.iloc[-3] and
        tmo.iloc[-1] > tmo.iloc[-3] and
        latest_roc > 0
    ):
        return {
            "symbol": symbol,
            "price": price,
            "direction": "多",
            "note": "價格背離上漲預警",
            "rsi": latest_rsi,
            "tmo": latest_tmo,
            "roc": latest_roc,
            "vwap_diff": (price - latest_vwap) / latest_vwap
        }

    if (
        df['close'].iloc[-1] > df['close'].iloc[-3] and
        rsi.iloc[-1] < rsi.iloc[-3] and
        tmo.iloc[-1] < tmo.iloc[-3] and
        latest_roc < 0
    ):
        return {
            "symbol": symbol,
            "price": price,
            "direction": "空",
            "note": "價格背離下跌預警",
            "rsi": latest_rsi,
            "tmo": latest_tmo,
            "roc": latest_roc,
            "vwap_diff": (price - latest_vwap) / latest_vwap
        }

    return None
